# The Fixer

## Original Text (from Volume 3: Crisis Profiles & Behavior Engines)

CRISIS PROFILE 03: THE FIXERCore Instinct: Control Through ActionCrisis Trigger: Perceived loss of group cohesion, helplessness, or failure to save someonePrimary Response: Hyper-tasking, micromanaging others, overextensionSecondary Response: Burnout, quiet resentment, collapse after success/failureBehavioral Signs:Sleep deprivation, hoarding of tools/tasksOrders others around without consensusNeglects emotional needs for productivityMay “fix” others instead of situationsSpiral Path:Becomes a controlling force, disregarding human cost. Cracks if deprived of action.Resilience Path:Refocuses efforts toward shared systems. Builds lasting infrastructure and earned trust.Group Effect:Helps at first, but may trigger resistanceLowers morale if others feel incompetentRaises tension in downtime or discussion scenes👻

---

## Mechanics (Crisis Profile Threshold System)

A **Crisis Profile** describes how this character destabilizes under sustained pressure. **The Fixer** uses three thresholds: *Activation*, *Escalation*, and *Breaking*.

### Activation Threshold

When stress, stakes, or social context line up with this profile’s **Core Instinct** and **Crisis Triggers** as described above, the GM may declare that **The Fixer is activating**.

- The GM calls for a **Trigger Roll** using the most relevant stat (often Sanity, Empathy, Survival, or Diplomacy).  
- On a **10+**, the character feels the pull of this profile but stays largely in control.  
- On a **7–9**, the profile colors their reactions, tone, or posture — they are clearly slipping toward this crisis mode.  
- On a **6–**, the profile takes firm hold; apply elements of the Escalation Threshold immediately.

### Escalation Threshold

If the situation continues or worsens — or if the character fails additional Trigger Rolls while The Fixer is active — the Crisis Profile escalates.

- Advance the relevant **Threat Clock** by 1 segment.  
- The character’s behaviors and instincts from this profile become more pronounced and harder to ignore.  
- The GM may call for **Trigger Rolls with disadvantage** while the character is acting directly from this crisis mode.  
- Social, tactical, or emotional fallout begins to accumulate for the group.

### Breaking Threshold

At a critical moment — often tied to a **Red Line**, major loss, or pivotal decision — the GM can declare that the character has reached the **Breaking Threshold** for The Fixer.

- The player **must** make a **Trigger Roll** with the most thematically appropriate stat.  
- On a **10+**, the character hits a **Resilience Path**: they recognize the pattern, ground themselves, and may begin to change how this crisis mode functions for them.  
- On a **7–9**, they remain in the grip of The Fixer, but with a sliver of self-awareness or control.  
- On a **6–**, they fully spiral into the **Spiral Path** for this profile.

---

### Spiral Path (Mechanical Effects)

When The Fixer spirals at the Breaking Threshold:

- For the rest of the scene, the character rolls with **disadvantage** or takes **–1 forward** on rolls where this crisis mode interferes.  
- Advance the current **Threat Clock by 1 segment** (or a particularly relevant threat clock by 2, at GM discretion).  
- Relationships, trust, or group stability are immediately strained in a way that reflects this profile’s behavioral patterns.  
- The GM frames at least one scene or beat where the group must respond to the damage caused by The Fixer in full crisis mode.

---

### Resilience Path (Mechanical Effects)

When the character reaches the Breaking Threshold and rolls a 10+, or otherwise demonstrates a major breakthrough related to The Fixer:

- The character gains **+1 forward** on a roll where they act in alignment with a healthier version of this profile (e.g., courage without recklessness, leadership without control, withdrawal with honest communication).  
- One ally directly affected by this crisis mode gains **advantage** on a roll to connect, support, or anchor the character.  
- Either **reduce a Threat Clock by 1 segment** or transform an impending consequence into a softer, more reparable version.  
- Mark **1 major growth milestone** toward evolving this Crisis Profile over the course of the campaign.

---

### Group Impact

The Fixer affects not only the individual, but also the **group dynamic**:

- Once per session, when The Fixer clearly shapes the emotional tone of the group (for good or ill), the GM may either:  
  - Grant the group a moment of hard-won cohesion and **+1 on a shared or coordinated roll**, **or**  
  - Impose **disadvantage** on a key group roll or scene if the crisis mode is tearing them apart.

Use the fiction and the profile’s original description to decide which outcome fits.
