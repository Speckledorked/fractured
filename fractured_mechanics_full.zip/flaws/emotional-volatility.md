# ️ Emotional Volatility

## Original Text (from Volume 2: Trait & Flaw Library)

☠️ Emotional VolatilityType: Behavioral Description: Anger, joy, grief—everything hits like a truck. Gameplay Effect: May roll with advantage or disadvantage depending on state. GM’s call. Triggers / Risk Factors: Interpersonal stress, betrayal, isolation. Evolution Path: “Burning Heart” or “Emotional Risk Factor”

---

## Mechanics (Unified Tension-Based System)

**Type:** Flaw

**Trigger Condition:**  
When **️ Emotional Volatility** meaningfully interferes with the character’s judgment, relationships, or ability to act — especially in high-stress or emotionally charged scenes — the GM calls for a **Trigger Roll**.

**Trigger Roll:**  
Roll **2d6 + the most relevant stat** (often Sanity, Empathy, or Diplomacy, depending on how ️ Emotional Volatility surfaces).

### On a 10+ – Resisted Flaw  
The character feels the pull of ️ Emotional Volatility, but manages to keep control. They still experience the emotion or impulse, but it does not dictate their behavior. They may gain insight or clarity about themselves.

### On a 7–9 – Strained Control  
The flaw influences behavior, tone, or decision-making. The character holds together, but something is strained: a relationship, a promise, a tactical position, or a resource. The GM introduces a cost that clearly flows from ️ Emotional Volatility.

### On a 6– – Full Collapse  
The flaw takes over in the moment. The character lashes out, freezes, withdraws, or misjudges the situation in a way that fits ️ Emotional Volatility. The GM makes a **Hard Move** and immediately applies the Spiral Path below.

---

### Spiral Path (Mechanical Effects)

When ️ Emotional Volatility spirals (typically on a 6– Trigger Roll):

- For the rest of the scene, the character either rolls with **disadvantage** or takes **–1 forward** on rolls opposed by or entangled with this flaw.  
- Advance the current **Threat Clock by 1 segment**.  
- Immediately hit the character’s **Crisis Profile Escalation Threshold**.  
- The GM frames a moment where ️ Emotional Volatility does real damage — to trust, safety, or the character’s own stability.

---

### Resilience Path (Mechanical Effects)

When the character confronts ️ Emotional Volatility honestly, makes a difficult healthier choice, or rolls a 10+ on a key Trigger Roll involving this flaw:

- The character gains **+1 forward** on their next roll where they act *against* this flaw’s usual pattern (showing growth or restraint).  
- Choose one ally affected by this flaw; that ally gains **advantage** on their next roll to support, forgive, or work with the character.  
- Either **reduce the Threat Clock by 1 segment** or soften a consequence that would have directly resulted from this flaw.  
- Mark **1 progress** toward *transforming* this flaw as part of the character’s long-term Growth Path.

